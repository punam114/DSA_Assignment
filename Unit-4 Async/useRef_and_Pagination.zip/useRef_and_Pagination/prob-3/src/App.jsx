import { useState } from 'react'
import './App.css'
import FocusInput from './FocusInput'

function App() {

  return (
    <>
      <FocusInput/>
    </>
  )
}

export default App
